
import csv
import sqlite3
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo

# --------------------------------------------------
# PATHS AND CONFIGURATION
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_PATH = BASE_DIR / "transport.db"

IST = ZoneInfo("Asia/Kolkata")


# --------------------------------------------------
# TIMESTAMP
# --------------------------------------------------

def current_timestamp():
    """Return the current time in Indian Standard Time."""
    return datetime.now(IST).isoformat(timespec="seconds")


# --------------------------------------------------
# DATABASE CONNECTION
# --------------------------------------------------

def get_connection():
    """Create a connection to the SQLite database."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


# --------------------------------------------------
# CREATE TABLES
# --------------------------------------------------

def init_db():
    """Create database tables if they do not exist."""

    with get_connection() as conn:

        conn.execute("""
            CREATE TABLE IF NOT EXISTS transport (
                id INTEGER PRIMARY KEY AUTOINCREMENT,

                transport_type TEXT NOT NULL,
                transport_number TEXT NOT NULL DEFAULT '',
                transport_name TEXT NOT NULL DEFAULT '',

                source TEXT NOT NULL DEFAULT '',
                destination TEXT NOT NULL DEFAULT '',

                departure_time TEXT NOT NULL DEFAULT '',
                arrival_time TEXT NOT NULL DEFAULT '',

                status TEXT NOT NULL DEFAULT 'Scheduled',

                source_url TEXT NOT NULL DEFAULT '',
                source_updated_at TEXT NOT NULL DEFAULT '',
                fetched_at TEXT NOT NULL,

                UNIQUE (
                    transport_type,
                    transport_number,
                    transport_name,
                    source,
                    destination,
                    departure_time,
                    arrival_time
                )
            )
        """)

        conn.execute("""
            CREATE TABLE IF NOT EXISTS service_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                transport_type TEXT NOT NULL,
                message TEXT NOT NULL,
                source_url TEXT NOT NULL DEFAULT '',
                fetched_at TEXT NOT NULL
            )
        """)

    print("Database tables initialized successfully.")


# --------------------------------------------------
# NORMALIZE CSV VALUES
# --------------------------------------------------

def clean_value(value):
    """Convert missing or blank values to empty strings."""
    if value is None:
        return ""
    return str(value).strip()


# --------------------------------------------------
# SAVE TRANSPORT RECORDS
# --------------------------------------------------

def save_transport(records, transport_type):
    """
    Insert transport records into SQLite.

    Expected CSV keys:
    transport_number, transport_name, source,
    destination, departure_time, arrival_time,
    status, source_url, source_updated_at, fetched_at
    """

    transport_type = clean_value(transport_type).lower()

    if transport_type not in ("bus", "train"):
        raise ValueError("transport_type must be 'bus' or 'train'")

    inserted = 0
    updated = 0

    with get_connection() as conn:

        for record in records:

            # Support the expected CSV columns.
            # The aliases also help with common alternative names.
            number = clean_value(
                record.get("transport_number")
                or record.get("bus_number")
                or record.get("train_number")
            )

            name = clean_value(
                record.get("transport_name")
                or record.get("bus_name")
                or record.get("train_name")
            )

            source = clean_value(
                record.get("source")
                or record.get("starting_point")
                or record.get("starting_station")
            )

            destination = clean_value(
                record.get("destination")
                or record.get("destination_station")
            )

            departure = clean_value(
                record.get("departure_time")
            )

            arrival = clean_value(
                record.get("arrival_time")
            )

            status = clean_value(record.get("status")) or "Scheduled"

            source_url = clean_value(record.get("source_url"))
            source_updated_at = clean_value(
                record.get("source_updated_at")
            )

            fetched_at = (
                clean_value(record.get("fetched_at"))
                or current_timestamp()
            )

            # Skip completely empty rows.
            if not any([
                number,
                name,
                source,
                destination,
                departure,
                arrival
            ]):
                continue

            cursor = conn.execute("""
                SELECT id
                FROM transport
                WHERE transport_type = ?
                  AND transport_number = ?
                  AND transport_name = ?
                  AND source = ?
                  AND destination = ?
                  AND departure_time = ?
                  AND arrival_time = ?
            """, (
                transport_type,
                number,
                name,
                source,
                destination,
                departure,
                arrival
            ))

            existing = cursor.fetchone()

            if existing:
                # Refresh metadata without creating duplicates.
                conn.execute("""
                    UPDATE transport
                    SET status = ?,
                        source_url = ?,
                        source_updated_at = ?,
                        fetched_at = ?
                    WHERE id = ?
                """, (
                    status,
                    source_url,
                    source_updated_at,
                    fetched_at,
                    existing["id"]
                ))
                updated += 1

            else:
                conn.execute("""
                    INSERT INTO transport (
                        transport_type,
                        transport_number,
                        transport_name,
                        source,
                        destination,
                        departure_time,
                        arrival_time,
                        status,
                        source_url,
                        source_updated_at,
                        fetched_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    transport_type,
                    number,
                    name,
                    source,
                    destination,
                    departure,
                    arrival,
                    status,
                    source_url,
                    source_updated_at,
                    fetched_at
                ))
                inserted += 1

    print(
        f"{transport_type.title()}: "
        f"{inserted} inserted, {updated} refreshed."
    )

    return {"inserted": inserted, "updated": updated}


# --------------------------------------------------
# IMPORT CSV FILE
# --------------------------------------------------

def import_csv_to_database(csv_filename, transport_type):
    """Read a CSV file and import all its records."""

    csv_path = DATA_DIR / csv_filename

    if not csv_path.exists():
        raise FileNotFoundError(
            f"CSV file not found: {csv_path}"
        )

    with open(
        csv_path,
        mode="r",
        newline="",
        encoding="utf-8-sig"
    ) as file:

        reader = csv.DictReader(file)

        if not reader.fieldnames:
            raise ValueError(
                f"{csv_filename} is empty or has no header row."
            )

        # Normalize header names to avoid spaces/case issues.
        reader.fieldnames = [
            name.strip().lower()
            for name in reader.fieldnames
        ]

        records = []

        for row in reader:
            normalized_row = {
                key.strip().lower(): clean_value(value)
                for key, value in row.items()
                if key is not None
            }

            records.append(normalized_row)

    result = save_transport(records, transport_type)

    print(
        f"Imported {len(records)} CSV rows from "
        f"{csv_filename}."
    )

    return result


# --------------------------------------------------
# GET BUS OR TRAIN RECORDS
# --------------------------------------------------

def get_transport(transport_type):
    """Return all records of the selected transport type."""

    transport_type = clean_value(transport_type).lower()

    with get_connection() as conn:
        rows = conn.execute("""
            SELECT *
            FROM transport
            WHERE transport_type = ?
            ORDER BY departure_time, transport_number
        """, (transport_type,)).fetchall()

    return [dict(row) for row in rows]


# --------------------------------------------------
# SEARCH TRANSPORT
# --------------------------------------------------

def search_transport(transport_type, query):
    """Search by number, name, source, or destination."""

    transport_type = clean_value(transport_type).lower()
    query = clean_value(query)

    with get_connection() as conn:

        if not query:
            return get_transport(transport_type)

        search_term = f"%{query}%"

        rows = conn.execute("""
            SELECT *
            FROM transport
            WHERE transport_type = ?
              AND (
                    transport_number LIKE ?
                 OR transport_name LIKE ?
                 OR source LIKE ?
                 OR destination LIKE ?
              )
            ORDER BY departure_time, transport_number
        """, (
            transport_type,
            search_term,
            search_term,
            search_term,
            search_term
        )).fetchall()

    return [dict(row) for row in rows]


# --------------------------------------------------
# SERVICE UPDATES
# --------------------------------------------------

def save_service_update(
    transport_type,
    message,
    source_url=""
):
    """Save a service announcement."""

    with get_connection() as conn:
        conn.execute("""
            INSERT INTO service_updates (
                transport_type,
                message,
                source_url,
                fetched_at
            )
            VALUES (?, ?, ?, ?)
        """, (
            clean_value(transport_type),
            clean_value(message),
            clean_value(source_url),
            current_timestamp()
        ))


def get_service_updates():
    """Return the latest 50 service announcements."""

    with get_connection() as conn:
        rows = conn.execute("""
            SELECT *
            FROM service_updates
            ORDER BY id DESC
            LIMIT 50
        """).fetchall()

    return [dict(row) for row in rows]


# --------------------------------------------------
# DISPLAY DATABASE CONTENT
# --------------------------------------------------

def print_transport_records(transport_type):
    """Print records to verify that data was imported."""

    records = get_transport(transport_type)

    print(f"\n--- {transport_type.upper()} RECORDS ---")

    if not records:
        print("No records found.")
        return

    for record in records:
        print(
            f"Number: {record['transport_number']} | "
            f"Name: {record['transport_name']} | "
            f"From: {record['source']} | "
            f"To: {record['destination']} | "
            f"Departure: {record['departure_time']} | "
            f"Arrival: {record['arrival_time']} | "
            f"Collected: {record['fetched_at']}"
        )


# --------------------------------------------------
# MAIN: IMPORT SAMPLE DATA AND VERIFY
# --------------------------------------------------

if __name__ == "__main__":

    init_db()

    import_csv_to_database(
        "bus_data.csv",
        "bus"
    )

    import_csv_to_database(
        "train_data.csv",
        "train"
    )

    print_transport_records("bus")
    print_transport_records("train")

    print("\nSample data import completed.")
