
from flask import Flask, render_template, request
from database import (
    init_db,
    get_transport,
    get_service_updates,
    import_csv_to_database
)
from datetime import datetime
from zoneinfo import ZoneInfo

app = Flask(__name__)

IST = ZoneInfo("Asia/Kolkata")


# Initialize database and import CSV sample records
init_db()

import_csv_to_database("bus_data.csv", "bus")
import_csv_to_database("train_data.csv", "train")


def current_timestamp():
    return datetime.now(IST).isoformat(timespec="seconds")


def filter_records(records, query):
    if not query:
        return records

    query = query.lower()

    return [
        record for record in records
        if query in str(record.get("source", "")).lower()
        or query in str(record.get("destination", "")).lower()
        or query in str(record.get("transport_number", "")).lower()
        or query in str(record.get("transport_name", "")).lower()
    ]


@app.route("/")
def index():
    return render_template(
        "index.html",
        timestamp=current_timestamp()
    )


@app.route("/bus")
def bus():
    query = request.args.get("q", "").strip()

    records = get_transport("bus")
    records = filter_records(records, query)

    return render_template(
        "bus.html",
        records=records,
        query=query,
        timestamp=current_timestamp()
    )


@app.route("/train")
def train():
    query = request.args.get("q", "").strip()

    records = get_transport("train")
    records = filter_records(records, query)

    return render_template(
        "train.html",
        records=records,
        query=query,
        timestamp=current_timestamp()
    )


@app.route("/service-updates")
def service_updates():
    updates = get_service_updates()

    return render_template(
        "service_updates.html",
        updates=updates,
        timestamp=current_timestamp()
    )


@app.route("/health")
def health():
    return {
        "status": "ok",
        "checked_at": current_timestamp()
    }


if __name__ == "__main__":
    app.run(
        debug=True,
        host="127.0.0.1",
        port=5000
    )
