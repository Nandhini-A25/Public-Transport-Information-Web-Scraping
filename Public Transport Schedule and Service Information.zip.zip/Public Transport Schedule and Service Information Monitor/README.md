# Public Transport Schedule and Service Information Monitor

## Project Overview

This project is a Python-based website that presents
public transport schedule and service information
for Tamil Nadu.

It is designed to support bus and train information
through a web interface.

## Technologies

- Python
- Flask
- SQLite
- Requests
- BeautifulSoup
- HTML
- CSS

## Main Features

1. Bus schedule search
2. Train schedule search
3. Transport information database
4. Service announcements
5. Timestamp recording
6. Automated route tests

## Project Structure

- app.py: Flask application
- database.py: Database operations
- scrapers/: Data collection modules
- data/: CSV datasets
- templates/: HTML pages
- static/: CSS styling
- tests/: Application tests

## Installation

Install the required packages:

    python -m pip install -r requirements.txt

## Run the Website

    python app.py

Open this address in your browser:

    http://127.0.0.1:5000

## Run Tests

    python -m unittest discover -s tests -v

## Data Freshness

The application records when data is collected.

The collection timestamp does not prove that the
source data is current.

Source update timestamps should be recorded
separately when available.

## Data Source Requirements

Use official or otherwise authorized data sources.

Check website terms, access restrictions, and
the freshness of each dataset before use.

The initial scraper examples check source
accessibility but do not yet populate the database
with complete transport schedules.

## Project Limitations

Real-time bus locations, live train positions,
cancellations, and delays require suitable
live data sources.

Static timetables cannot establish current
vehicle locations or delays.