import unittest

from app import app


class TransportMonitorTests(unittest.TestCase):

    def setUp(self):
        app.config["TESTING"] = True
        self.client = app.test_client()

    def test_homepage(self):
        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)

        self.assertIn(
            b"Public Transport Monitor",
            response.data
        )

    def test_bus_page(self):
        response = self.client.get("/bus")

        self.assertEqual(response.status_code, 200)

    def test_train_page(self):
        response = self.client.get("/train")

        self.assertEqual(response.status_code, 200)

    def test_service_updates_page(self):
        response = self.client.get("/service-updates")

        self.assertEqual(response.status_code, 200)

    def test_health_endpoint(self):
        response = self.client.get("/health")

        self.assertEqual(response.status_code, 200)

        data = response.get_json()

        self.assertEqual(data["status"], "ok")
        self.assertIn("checked_at", data)


if __name__ == "__main__":
    unittest.main()