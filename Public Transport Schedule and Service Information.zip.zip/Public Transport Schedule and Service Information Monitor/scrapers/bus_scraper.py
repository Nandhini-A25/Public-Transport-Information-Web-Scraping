import requests
from bs4 import BeautifulSoup
from datetime import datetime
from zoneinfo import ZoneInfo

BUS_URL = (
    "https://mtcbus.tn.gov.in/"
    "Home/bustypetimingsearch"
)

IST = ZoneInfo("Asia/Kolkata")


def scrape_bus_page():
    fetched_at = datetime.now(IST).isoformat(
        timespec="seconds"
    )

    headers = {
        "User-Agent": (
            "PublicTransportMonitor/1.0 "
            "(educational project)"
        )
    }

    try:
        response = requests.get(
            BUS_URL,
            headers=headers,
            timeout=20
        )

        response.raise_for_status()

        content_type = response.headers.get(
            "Content-Type", ""
        )

        if "html" not in content_type.lower():
            return {
                "success": False,
                "message": "The source did not return HTML.",
                "fetched_at": fetched_at,
                "source_url": BUS_URL,
                "records": []
            }

        soup = BeautifulSoup(
            response.text,
            "html.parser"
        )

        page_text = soup.get_text(
            " ",
            strip=True
        )

        # This is a connectivity/content check,
        # not a complete timetable parser.
        if not page_text:
            return {
                "success": False,
                "message": "The page contains no readable text.",
                "fetched_at": fetched_at,
                "source_url": BUS_URL,
                "records": []
            }

        return {
            "success": True,
            "message": (
                "Official bus page retrieved. "
                "Verify the timetable structure before "
                "extracting individual schedules."
            ),
            "fetched_at": fetched_at,
            "source_url": BUS_URL,
            "records": [],
            "page_title": (
                soup.title.get_text(strip=True)
                if soup.title else ""
            )
        }

    except requests.RequestException as error:
        return {
            "success": False,
            "message": f"Bus source unavailable: {error}",
            "fetched_at": fetched_at,
            "source_url": BUS_URL,
            "records": []
        }


if __name__ == "__main__":
    result = scrape_bus_page()

    print("Source:", result["source_url"])
    print("Fetched at:", result["fetched_at"])
    print("Success:", result["success"])
    print("Message:", result["message"])

    if result.get("page_title"):
        print("Page title:", result["page_title"])