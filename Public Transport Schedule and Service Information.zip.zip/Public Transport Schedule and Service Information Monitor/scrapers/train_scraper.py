import requests
from datetime import datetime
from zoneinfo import ZoneInfo

CATALOG_URL = (
    "https://www.data.gov.in/catalog/"
    "indian-railways-train-time-table"
)

IST = ZoneInfo("Asia/Kolkata")


def check_train_source():
    fetched_at = datetime.now(IST).isoformat(
        timespec="seconds"
    )

    headers = {
        "User-Agent": (
            "PublicTransportMonitor/1.0 "
            "(educational project)"
        )
    }

    try:
        response = requests.get(
            CATALOG_URL,
            headers=headers,
            timeout=20
        )

        response.raise_for_status()

        return {
            "success": True,
            "message": (
                "Government timetable catalog retrieved. "
                "Find and configure the actual dataset "
                "download or authorized API endpoint."
            ),
            "fetched_at": fetched_at,
            "source_url": CATALOG_URL,
            "records": []
        }

    except requests.RequestException as error:
        return {
            "success": False,
            "message": (
                f"Train timetable source unavailable: {error}"
            ),
            "fetched_at": fetched_at,
            "source_url": CATALOG_URL,
            "records": []
        }


if __name__ == "__main__":
    result = check_train_source()

    print("Source:", result["source_url"])
    print("Fetched at:", result["fetched_at"])
    print("Success:", result["success"])
    print("Message:", result["message"])